//
//  AssignmentApp.swift
//  Assignment
//
//  Created by Viveka SriVardhini on 13/11/25.
//

import SwiftUI

@main
struct AssignmentApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
