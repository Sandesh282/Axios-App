import SwiftUI

struct ContentView: View {
    var body: some View {
        
        ZStack {
            
            LinearGradient(gradient: Gradient(colors: [.blue, .cyan]), startPoint: .topLeading, endPoint: .bottomTrailing)
                .ignoresSafeArea()
            
            VStack(alignment:.leading, spacing:15) {
                
                HStack {
                    
                    Image("Profile")
                        .resizable()
                        .scaledToFill()
                        .frame(width: 100, height: 100)
                        .padding(5)
                    
                    VStack(alignment:.leading, spacing:2) {
                        
                        Text("Krrish Dixit")
                            .font(.title)
                            .foregroundStyle(.white)
                        
                        Text("Age 19")
                            .font(.subheadline)
                            .foregroundStyle(.white)
                        
                    }
                }
                .padding(-5)
                .padding(.top, 20)
                
                HStack {
                    
                    VStack(alignment:.leading, spacing:8) {
                        Text("About")
                            .font(.title2)
                            .padding(0)
                            .foregroundStyle(.white)
                            
                        Text("iOS Enthusiast, Problem Solver, and an Aspiring Developer.")
                            .font(.subheadline)
                            .frame(width: 250, height:50)
                            .lineSpacing(5)
                            .foregroundStyle(.white)
                            .padding(0)
                        
                    }
                }
                
                Text("Gallery")
                    .font(.title2)
                    .foregroundStyle(.white)
                
                
                ForEach(0..<4) { _ in
                    HStack {
                        ForEach(0..<3) { _ in
                            ZStack {
                                RoundedRectangle(cornerRadius: 20)
                                    .fill(.gray.opacity(0.15))
                                    .frame(width: 125, height: 125)
                            
                                Image(systemName: "photo")
                                    .resizable()
                                    .frame(width: 42, height: 35)
                            }
                        }
                        
                    }
                }
                
                

                
            }

            
        }
        
    }
}

#Preview {
    ContentView()
}
