//
//  Assignmnet1App.swift
//  Assignmnet1
//
//  Created by Krrish Dixit on 08/11/25.
//

import SwiftUI

@main
struct Assignmnet1App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
