//
//  ContentView.swift
//  SwiftfulThinkingBootcamp
//
//  Created by Kartikey Chaudhary on 13/11/25.
//
import SwiftUI

struct ContentView: View {
    var body: some View {
        ZStack {
            LinearGradient(
                gradient: Gradient(colors: [Color.black, Color.blue]),
                startPoint: .top,
                endPoint: .bottom
            )
            

            VStack(spacing: 24) {
                HStack(spacing: 12) {
                    ProfileHeaderView()
                }
                

                VStack(alignment: .leading, spacing: 11) {
                    BioView()
                }
                .padding(.horizontal)
                
                VStack(alignment: .leading, spacing: 12) {
                    Text("Gallery")
                        .font(.headline)
                        .bold()
                        .foregroundColor(.white)
                        .padding(.horizontal)
///
                    VStack(spacing: 12){
                        GalleryView()
                    }
                    
                }

//                Spacer()
            }
            .padding(.top, 60)
        }
        .ignoresSafeArea()
    }
}

struct ProfileHeaderView: View {
    var body: some View {
        ZStack {
            Circle()
                .fill(Color.blue.opacity(0.3))
                .frame(width: 120, height: 120)
                .blur(radius: 10)
            
            Image(systemName: "person.circle.fill")
                .resizable()
                .frame(width: 110.0, height: 110.0)
                .foregroundColor(.blue)
        }
        VStack(alignment: .leading, spacing:8) {
            Text("Kartikey Chaudhary")
                .font(.title)
                .bold()
                .foregroundColor(.white)
            
            
            Text("Age 19")
                .font(.subheadline)
                .foregroundColor(.white.opacity(0.7))
        }
    }
}

struct BioView: View {
    var body: some View {
        Text("Bio")
            .font(.headline)
            .foregroundColor(.white)

        Text("iOS Developer, coffee enthusiast, and part-time bug fixer")
            .font(.subheadline)
            .foregroundColor(.white.opacity(0.7))
            .multilineTextAlignment(.leading)
    }
}

struct GalleryView: View {
    var body: some View {
        ForEach(0..<4) { _ in
            HStack(spacing: 12) {
                ForEach(0..<3) { _ in
                    ZStack {
                        RoundedRectangle(cornerRadius: 11)
                            .fill(Color.blue.opacity(0.15))
                            .frame(width: 115, height: 105)

                        Image(systemName: "photo")
                            .resizable()
                            .scaledToFit()
                            .frame(width: 40, height: 40)
                            .foregroundColor(.white.opacity(0.6))
                    }
                }
            }
        }
    }
}
#Preview {
    ContentView()
}
