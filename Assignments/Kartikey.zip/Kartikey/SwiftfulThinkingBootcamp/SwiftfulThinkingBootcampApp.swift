//
//  SwiftfulThinkingBootcampApp.swift
//  SwiftfulThinkingBootcamp
//
//  Created by Kartikey Chaudhary on 13/11/25.
//

import SwiftUI

@main
struct SwiftfulThinkingBootcampApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
